with open('사회문화-입력.txt','r', encoding='utf-8') as 입력값파일, open('사회문화-정답.txt', 'r', encoding='utf-8') as 정답파일, open('사회문화-해설.txt', 'r', encoding='utf-8') as 해설파일, open('사회문화-점수(출력용).txt', 'r', encoding='utf-8') as 점수확인파일, open('사회문화-점수(계산용).txt', 'r', encoding='utf-8') as 점수계산파일:
    입력값 = 입력값파일.read().split(",") #입력값=본인이 선택한 답
    정답 = 정답파일.read().split(",") #정답=문제의 정답
    해설 = 해설파일.read().split(":") #해설=문제에 대한 해설
    점수확인 = 점수확인파일.read().split(":") #점수확인=정답 시 '정답입니다(+점수)'출력용
    점수계산 = 점수계산파일.read().split(",") #점수계산=총점 및 등급 계산을 위한 점수 파일

점수 = 0
for i in range(len(입력값)):
    입력값밸류 = 입력값[i].strip()
    정답밸류 = 정답[i].strip()
    if 입력값밸류 == 정답밸류: #본인이 선택한 것과 문제의 정답 대조
        print(점수확인[i]) #정답일 경우 점수확인 출력
        점수 = int(점수) + int(점수계산[i]) #원래 있던 점수와 합산
    else:
        print(해설[i]) #오답일 경우 해설 출력

#등급 산정 코드(feat. 메가스터디)
if 점수 <= 50 and 점수 >= 42:
    등급 = str(1)
elif 점수 <= 41 and 점수 >= 39:
    등급 = str(2)
elif 점수 <= 38 and 점수 >= 34:
    등급 = str(3)
elif 점수 <= 33 and 점수 >= 29:
    등급 = str(4)
elif 점수 <= 28 and 점수 >= 23:
    등급 = str(5)
elif 점수 <= 22 and 점수 >= 18:
    등급 = str(6)
elif 점수 <= 17 and 점수 >= 11:
    등급 = str(7)
elif 점수 <= 10 and 점수 >= 8:
    등급 = str(8)
elif 점수 <= 7 and 점수 >= 0:
    등급 = str(9)
print()
print("사회문화의 총점은 " + str(점수) + "점, " + str(등급) +"등급 입니다. 수고하셨습니다.") #결과 출력